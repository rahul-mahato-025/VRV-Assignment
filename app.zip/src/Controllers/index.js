module.exports = {
  userController: require("./user.controller"),
  roleController: require("./role.controller"),
  authController: require("./auth.controller"),
};
