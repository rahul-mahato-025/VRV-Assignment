const RoleDto = require("./role.dto");
const UserDto = require("./user.dto");

module.exports = {
  RoleDto,
  UserDto,
};
