const CrudRepository = require("./crud.repo");
const RoleRepository = require("./role.repo");
const UserRepository = require("./user.repo");

module.exports = {
  CrudRepository,
  UserRepository,
  RoleRepository,
};
